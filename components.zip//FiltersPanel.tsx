import { FilterState } from '../types/restaurant';
import { Button } from './ui/button';
import { Label } from './ui/label';

interface FiltersPanelProps {
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
  onApply: () => void;
  onReset: () => void;
}

const categories = ['中式', '日式', '韓式', '美式', '義式', '泰式', '越南', '印度'];
const priceRanges = ['$', '$$', '$$$'];

export function FiltersPanel({ filters, onFilterChange, onApply, onReset }: FiltersPanelProps) {
  const toggleCategory = (category: string) => {
    const newCategories = filters.categories.includes(category)
      ? filters.categories.filter(c => c !== category)
      : [...filters.categories, category];
    onFilterChange({ ...filters, categories: newCategories });
  };

  const togglePriceRange = (price: string) => {
    const newPriceRanges = filters.priceRanges.includes(price)
      ? filters.priceRanges.filter(p => p !== price)
      : [...filters.priceRanges, price];
    onFilterChange({ ...filters, priceRanges: newPriceRanges });
  };

  return (
    <div className="w-full max-w-md mx-auto bg-white rounded-lg p-6 space-y-6">
      <h2>Filters</h2>
      
      <div>
        <Label className="mb-3 block">餐點類型</Label>
        <div className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => toggleCategory(category)}
              className={`px-4 py-2 rounded-md border transition-colors ${
                filters.categories.includes(category)
                  ? 'bg-[#E89BA8] text-white border-[#E89BA8]'
                  : 'bg-white text-gray-700 border-gray-300 hover:border-[#E89BA8]'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      <div>
        <Label className="mb-3 block">價格範圍</Label>
        <div className="flex gap-3">
          {priceRanges.map((price) => (
            <button
              key={price}
              onClick={() => togglePriceRange(price)}
              className={`px-6 py-2 rounded-md border transition-colors ${
                filters.priceRanges.includes(price)
                  ? 'bg-[#E89BA8] text-white border-[#E89BA8]'
                  : 'bg-white text-gray-700 border-gray-300 hover:border-[#E89BA8]'
              }`}
            >
              {price}
            </button>
          ))}
        </div>
      </div>

      <div>
        <Label className="mb-3 block">排名數據來源</Label>
        <div className="flex flex-wrap gap-2">
          <button className="px-4 py-2 rounded-md bg-[#FFF4E6] text-gray-700 border border-[#FFD9A0]">
            GOOGLE
          </button>
          <button className="px-4 py-2 rounded-md bg-[#FFF4E6] text-gray-700 border border-[#FFD9A0]">
            INSTAGRAM
          </button>
          <button className="px-4 py-2 rounded-md bg-[#FFF4E6] text-gray-700 border border-[#FFD9A0]">
            FACEBOOK
          </button>
        </div>
      </div>

      <div className="flex gap-3 pt-4">
        <Button
          variant="outline"
          onClick={onReset}
          className="flex-1"
        >
          Reset
        </Button>
        <Button
          onClick={onApply}
          className="flex-1 bg-[#E89BA8] hover:bg-[#D88A98] text-white"
        >
          Apply Filters
        </Button>
      </div>
    </div>
  );
}
