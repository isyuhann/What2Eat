import { Restaurant } from '../types/restaurant';
import { Heart, MapPin } from 'lucide-react';
import { Button } from './ui/button';

interface FavoritesListProps {
  favorites: Restaurant[];
  onToggleFavorite: (restaurantId: string) => void;
}

export function FavoritesList({ favorites, onToggleFavorite }: FavoritesListProps) {
  const openGoogleMaps = (restaurant: Restaurant) => {
    if (restaurant.lat && restaurant.lng) {
      window.open(
        `https://www.google.com/maps/search/?api=1&query=${restaurant.lat},${restaurant.lng}`,
        '_blank'
      );
    } else {
      window.open(
        `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(restaurant.name + ' ' + restaurant.location)}`,
        '_blank'
      );
    }
  };

  if (favorites.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">還沒有收藏的餐廳</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {favorites.map((restaurant) => (
        <div
          key={restaurant.id}
          className="bg-white rounded-lg p-4 shadow-sm border border-gray-200 flex items-start gap-4"
        >
          <div className="w-12 h-12 bg-[#FFE4E8] rounded-full flex items-center justify-center flex-shrink-0">
            <span className="text-2xl">🍜</span>
          </div>
          
          <div className="flex-1 min-w-0">
            <h4 className="mb-1">{restaurant.name}</h4>
            <p className="text-sm text-gray-600 mb-2">{restaurant.location}</p>
            <div className="flex gap-2">
              <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs">
                {restaurant.category}
              </span>
              <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs">
                {restaurant.priceRange}
              </span>
            </div>
          </div>

          <div className="flex gap-2 flex-shrink-0">
            <Button
              size="icon"
              variant="ghost"
              onClick={() => openGoogleMaps(restaurant)}
              className="text-blue-500 hover:text-blue-600 hover:bg-blue-50"
            >
              <MapPin className="w-4 h-4" />
            </Button>
            <Button
              size="icon"
              variant="ghost"
              onClick={() => onToggleFavorite(restaurant.id)}
              className="text-red-500 hover:text-red-600 hover:bg-red-50"
            >
              <Heart className="w-4 h-4 fill-red-500" />
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}
