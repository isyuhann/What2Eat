import { Restaurant } from '../types/restaurant';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from './ui/dialog';
import { Button } from './ui/button';
import { MapPin, Heart } from 'lucide-react';

interface ResultDialogProps {
  restaurant: Restaurant | null;
  open: boolean;
  onClose: () => void;
  onToggleFavorite: (restaurantId: string) => void;
}

export function ResultDialog({ restaurant, open, onClose, onToggleFavorite }: ResultDialogProps) {
  if (!restaurant) return null;

  const openGoogleMaps = () => {
    if (restaurant.lat && restaurant.lng) {
      window.open(
        `https://www.google.com/maps/search/?api=1&query=${restaurant.lat},${restaurant.lng}`,
        '_blank'
      );
    } else {
      window.open(
        `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(restaurant.name + ' ' + restaurant.location)}`,
        '_blank'
      );
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center text-2xl">🎉 恭喜！</DialogTitle>
          <DialogDescription className="text-center">
            你今天的餐廳是...
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-6 space-y-4">
          <div className="text-center">
            <h3 className="text-3xl mb-2">{restaurant.name}</h3>
            <p className="text-gray-600">{restaurant.location}</p>
            <div className="flex items-center justify-center gap-4 mt-3">
              <span className="px-3 py-1 bg-[#E89BA8] text-white rounded-full text-sm">
                {restaurant.category}
              </span>
              <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                {restaurant.priceRange}
              </span>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={openGoogleMaps}
              className="flex-1 bg-blue-500 hover:bg-blue-600 text-white"
            >
              <MapPin className="w-4 h-4 mr-2" />
              Google Maps
            </Button>
            <Button
              onClick={() => onToggleFavorite(restaurant.id)}
              variant="outline"
              className={`flex-1 ${restaurant.isFavorite ? 'bg-red-50 border-red-300' : ''}`}
            >
              <Heart
                className={`w-4 h-4 mr-2 ${restaurant.isFavorite ? 'fill-red-500 text-red-500' : ''}`}
              />
              {restaurant.isFavorite ? '已收藏' : '加入最愛'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
