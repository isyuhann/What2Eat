import { useState, useRef } from 'react';
import { Restaurant } from '../types/restaurant';
import { Button } from './ui/button';
import { motion } from 'motion/react';

interface TurntableWheelProps {
  restaurants: Restaurant[];
  onResult: (restaurant: Restaurant) => void;
}

export function TurntableWheel({ restaurants, onResult }: TurntableWheelProps) {
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);

  const spinWheel = () => {
    if (isSpinning || restaurants.length === 0) return;

    setIsSpinning(true);
    
    // Random number of full rotations (5-10) plus random final position
    const fullRotations = 5 + Math.floor(Math.random() * 5);
    const randomIndex = Math.floor(Math.random() * restaurants.length);
    const degreesPerSlice = 360 / restaurants.length;
    const finalDegree = fullRotations * 360 + randomIndex * degreesPerSlice;
    
    setRotation(finalDegree);

    setTimeout(() => {
      setIsSpinning(false);
      onResult(restaurants[randomIndex]);
    }, 3000);
  };

  const colors = ['#FFB6C1', '#FFA07A', '#FFD700', '#98D8C8', '#B0C4DE', '#DDA0DD', '#F0E68C', '#87CEEB'];

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="relative w-80 h-80">
        {/* Pointer at top */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-2 z-10">
          <div className="w-0 h-0 border-l-[15px] border-l-transparent border-r-[15px] border-r-transparent border-t-[25px] border-t-red-500"></div>
        </div>

        {/* Wheel */}
        <motion.div
          className="w-full h-full rounded-full relative overflow-hidden shadow-xl"
          animate={{ rotate: rotation }}
          transition={{ duration: 3, ease: "easeOut" }}
        >
          {restaurants.length > 0 ? (
            <svg viewBox="0 0 200 200" className="w-full h-full">
              {restaurants.map((restaurant, index) => {
                const sliceAngle = 360 / restaurants.length;
                const startAngle = index * sliceAngle - 90;
                const endAngle = startAngle + sliceAngle;
                
                const startRad = (startAngle * Math.PI) / 180;
                const endRad = (endAngle * Math.PI) / 180;
                
                const x1 = 100 + 100 * Math.cos(startRad);
                const y1 = 100 + 100 * Math.sin(startRad);
                const x2 = 100 + 100 * Math.cos(endRad);
                const y2 = 100 + 100 * Math.sin(endRad);
                
                const largeArc = sliceAngle > 180 ? 1 : 0;
                
                const pathData = `M 100 100 L ${x1} ${y1} A 100 100 0 ${largeArc} 1 ${x2} ${y2} Z`;
                
                const textAngle = startAngle + sliceAngle / 2;
                const textRad = (textAngle * Math.PI) / 180;
                const textX = 100 + 60 * Math.cos(textRad);
                const textY = 100 + 60 * Math.sin(textRad);
                
                return (
                  <g key={restaurant.id}>
                    <path
                      d={pathData}
                      fill={colors[index % colors.length]}
                      stroke="white"
                      strokeWidth="2"
                    />
                    <text
                      x={textX}
                      y={textY}
                      textAnchor="middle"
                      dominantBaseline="middle"
                      transform={`rotate(${textAngle + 90}, ${textX}, ${textY})`}
                      className="text-[8px] fill-gray-800 pointer-events-none select-none"
                      style={{ fontWeight: 600 }}
                    >
                      {restaurant.name}
                    </text>
                  </g>
                );
              })}
            </svg>
          ) : (
            <div className="w-full h-full bg-gray-200 flex items-center justify-center rounded-full">
              <p className="text-gray-500">沒有餐廳可選擇</p>
            </div>
          )}
        </motion.div>

        {/* Center circle */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 bg-white rounded-full shadow-lg border-4 border-gray-300"></div>
      </div>

      <Button
        onClick={spinWheel}
        disabled={isSpinning || restaurants.length === 0}
        className="bg-[#E89BA8] hover:bg-[#D88A98] text-white px-8 py-6"
      >
        {isSpinning ? '轉盤中...' : 'Spin Now'}
      </Button>
    </div>
  );
}
